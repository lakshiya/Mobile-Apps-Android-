package com.example.t2.database;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class insert extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        SQLiteDatabase.CursorFactory factory;

        final DatabaseHandler db = new DatabaseHandler(this);
        Log.d("hey","Db is created");

        Button back = (Button) findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                setContentView(R.layout.activity_main);
            }
        });

        Button submit = (Button) findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText editText = (EditText) findViewById(R.id.name);
                // EditText editText1 = (EditText) findViewById(R.id.gender_group);
                Spinner spinner  = (Spinner) findViewById(R.id.department);
                EditText editTex3 = (EditText) findViewById(R.id.number);
                Integer numb = Integer.parseInt(editTex3.getText().toString());
                // Long phno = Float.parseFloat(editTex3.getText().toString());
                String name = editText.getText().toString();


                float val = db.insertVal(name,"male","eee",numb);

              // float val =  db.insertVal(new student(name,"male","eee",numb));

                Toast toast = Toast.makeText(getApplicationContext(), "Inserted "+val+"  yes",
                        Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP|Gravity.LEFT, 300, 1400);
                toast.show();
            }
        });



    }
}
