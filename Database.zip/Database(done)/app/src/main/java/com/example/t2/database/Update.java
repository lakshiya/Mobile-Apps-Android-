package com.example.t2.database;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Update extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        Button goUpdate = (Button) findViewById(R.id.goUpdate);

        final EditText editText = (EditText) findViewById(R.id.conNum);

        goUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(),ChangeActivity.class);

                Integer phno = Integer.parseInt(editText.getText().toString());
                final Bundle b = new Bundle();

                b.putInt("oldno",phno);
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_change);
            }
        });
    }
}
