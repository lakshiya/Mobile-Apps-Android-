package com.example.t2.database;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class ResultActivity extends AppCompatActivity {

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        final DatabaseHandler db = new DatabaseHandler(this);
        Intent in = getIntent();
        Bundle b = in.getExtras();
        Integer pno = b.getInt("phno");

//        ScrollView scrollView = new ScrollView(this);
//        scrollView.setLayoutParams(new ScrollView.LayoutParams(ScrollView.LayoutParams.WRAP_CONTENT, ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

//        scrollView.addView(layout);
        //ScrollView scrollView = new ScrollView(this);

        TextView titleView = new TextView(this);
        LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleView.setLayoutParams(lparams);
        titleView.setTextAppearance(this, android.R.attr.textAppearanceLarge);
        titleView.setText("Student Database");
        titleView.setTextSize(30);
        layout.addView(titleView);

        setContentView(layout);

        Cursor cursor = db.retrieveVal(pno);

            if(cursor!=null)
            {


                if(cursor.moveToNext())
                {
                    Toast.makeText(getApplicationContext(),"Got it GAAAL",Toast.LENGTH_LONG).show();

                    do{
                        String sname = cursor.getString(cursor.getColumnIndex("Name"));

                        Toast.makeText(getApplicationContext(),"the name :"+sname,Toast.LENGTH_LONG).show();

                        TextView name = new TextView(this);
                        LinearLayout.LayoutParams lparams1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        name.setLayoutParams(lparams1);
                        name.setTextSize(20);
                        name.setTextAppearance(this, android.R.attr.textAppearanceLarge);
                        name.setText("Name :" + sname);
                        layout.addView(name);

                        String sdept = cursor.getString(cursor.getColumnIndex("Department"));

                        Toast.makeText(getApplicationContext(),"the name :"+sname,Toast.LENGTH_LONG).show();

                        TextView department = new TextView(this);
                        LinearLayout.LayoutParams lparams2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        department.setLayoutParams(lparams2);
                        department.setTextAppearance(this, android.R.attr.textAppearanceLarge);
                        department.setText("Department :" + sdept);
                        department.setTextSize(20);
                        layout.addView(department);

//                        float idval = cursor.getFloat(cursor.getColumnIndex("_id"));
//
//                        Toast.makeText(getApplicationContext(),"the name :"+sname,Toast.LENGTH_LONG).show();
//
//                        TextView sid = new TextView(this);
//                        LinearLayout.LayoutParams lparams3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
//                        sid.setLayoutParams(lparams2);
//                        sid.setTextAppearance(this, android.R.attr.textAppearanceLarge);
//                        sid.setText("SNO :" + idval);
//                        sid.setTextSize(35);
//                        layout.addView(sid);

                        String gender = cursor.getString(cursor.getColumnIndex("Gender"));

                      //  Toast.makeText(getApplicationContext(),"the name :"+sname,Toast.LENGTH_LONG).show();

                        TextView gend = new TextView(this);
                        LinearLayout.LayoutParams lparams4 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        gend.setLayoutParams(lparams4);
                        gend.setTextAppearance(this, android.R.attr.textAppearanceLarge);
                        gend.setText("Gender :" + gender);
                        gend.setTextSize(20);
                        layout.addView(gend);

                        int cnumb = cursor.getInt(cursor.getColumnIndex("cnum"));

                        //Toast.makeText(getApplicationContext(),"the name :"+sname,Toast.LENGTH_LONG).show();

                        TextView cnum = new TextView(this);
                        LinearLayout.LayoutParams lparams5 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        cnum.setLayoutParams(lparams5);
                        cnum.setTextAppearance(this, android.R.attr.textAppearanceLarge);
                        cnum.setText("Ph no :" + cnumb);
                        cnum.setTextSize(20);
                        layout.addView(cnum);

                    }while (cursor.moveToNext());
                }
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Errorrrr ",Toast.LENGTH_LONG).show();

            }
          //  scrollView.addView(layout);
    }
}
