package com.example.t2.database;

/**
 * Created by priya on 20/1/18.
 */

public class student {

    public String name;
    public String gender;
    public String department;
    public long phno ;

    student()
    {}

    student(String name,String gender ,String department ,long phno)
    {
        this.name=name;
        this.gender=gender;
        this.department=department;
        this.phno=phno;
    }

    public String getName() {
        return name;
    }

    public String getGender(){
        return  gender;
    }

    public String getDepartment(){
        return  department;
    }
    public long getPhno(){
        return  phno;
    }

    public void  setName(String name)
    {
        this.name = name;
    }

    public void  setGender(String gender)
    {
        this.gender = gender;
    }

    public void  setDepartment(String department)
    {
        this.department = department;
    }

    public void setPhno(long phno)
    {
        this.phno = phno;
    }

}
