package com.example.t2.database;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DeleteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);


        final DatabaseHandler db = new DatabaseHandler(this);
        Button goDelete = (Button) findViewById(R.id.goDelete);

        final EditText editText = (EditText) findViewById(R.id.conNum);

        goDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Integer phno = Integer.parseInt(editText.getText().toString());
                db.deleteVal(phno);

            }
        });
    }
}
