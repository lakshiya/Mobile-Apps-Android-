package com.example.t2.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

/**
 * Created by priya on 20/1/18.
 */

public class DatabaseHandler extends SQLiteOpenHelper {

    private  static final String db_name = "students";
    private  static final String key_name = "Name";
    private  static final String key_gender = "Gender";
    private  static final String key_department = "Department";
    private  static final String key_cnum = "cnum";
    private static final  String key_id = "_id";

    public DatabaseHandler(Context context) {
        super(context,db_name,null, (int) 1.0);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

       String drop = "DROP TABLE IF EXISTS STUDENTS;";
        sqLiteDatabase.execSQL(drop);

       String create_table = "CREATE TABLE IF NOT EXISTS STUDENTS ( " + key_id +" INTEGER ,"+ key_name +" char(50),"+ key_gender+" char(15),"+key_department+" char(20),"+key_cnum+"  char(15));";
            sqLiteDatabase.execSQL(create_table);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        onCreate(sqLiteDatabase);

    }

    public float insertVal(String name,String gender,String department,int phno)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(key_id,22);
        contentValues.put(key_name,name);
        contentValues.put(key_gender,gender);
        contentValues.put(key_department,department);
        contentValues.put(key_cnum,phno);

        long value = db.insert(db_name,null,contentValues);

        Log.d("ok","Is Inserted "+value);
        db.close();

        return value;
    }

    public float updateVal(String name,String gender,String department,int phno,int oldno)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        if(name!=null)
        {
            Cursor cursor = db.rawQuery("UPDATE STUDENTS SET NAME ='"+name+"' WHERE CNUM = '"+oldno+"'",null);
            cursor.moveToFirst();
            cursor.close();
        }

        if(gender!=null)
        {
            Cursor cursor2 = db.rawQuery("UPDATE STUDENTS SET GENDER ='"+gender+"' WHERE CNUM = '"+oldno+"'",null);
            cursor2.moveToFirst();
            cursor2.close();
        }

        if(department!=null)
        {
            Cursor cursor3 = db.rawQuery("UPDATE STUDENTS SET DEPARTMENT ='"+department+"' WHERE CNUM = '"+oldno+"'",null);
           cursor3.moveToFirst();
           cursor3.close();
        }

        if(phno!=0)
        {
            Cursor cursor4 = db.rawQuery("UPDATE STUDENTS SET CNUM ='"+phno+"' WHERE CNUM = '"+oldno+"'",null);
           cursor4.moveToFirst();
           cursor4.close();
        }
        return 1;
    }

    public Cursor retrieveVal(Integer phno) {
        SQLiteDatabase db = this.getReadableDatabase();

        if (phno == -1) {
            Cursor cursor = db.rawQuery("SELECT * FROM STUDENTS ", null);
            return cursor;
        }

        else
        {
            String num = phno.toString();
            Cursor cursor = db.rawQuery("SELECT * FROM STUDENTS WHERE CNUM= '"+num+"'",null);
            return cursor;

        }
    }

    public void deleteVal(Integer phno) {
        SQLiteDatabase db = this.getWritableDatabase();

            String num = phno.toString();
            Cursor cursor = db.rawQuery("DELETE FROM STUDENTS WHERE CNUM= '"+num+"'",null);
            Log.d("check","DELETE FROM STUDENTS WHERE CNUM= "+num);
            cursor.moveToNext();
            cursor.close();


    }

}
