package com.example.t2.database;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RetrieveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrieve);

        Button go = (Button) findViewById(R.id.go);
        Button getAll = (Button) findViewById(R.id.getAll);
        final EditText editText = (EditText) findViewById(R.id.conNum);

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),ResultActivity.class);

                Integer phno = Integer.parseInt(editText.getText().toString());
                final Bundle b = new Bundle();

                b.putInt("phno",phno);
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_result);



            }
        });

        getAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),ResultActivity.class);

                Integer phno = -1;
                final Bundle b = new Bundle();

                b.putInt("phno",phno);
                i.putExtras(b);

                startActivity(i);
                setContentView(R.layout.activity_result);



            }
        });


    }
}
