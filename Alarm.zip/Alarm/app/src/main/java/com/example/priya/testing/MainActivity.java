package com.example.priya.testing;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.Ringtone;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.sql.Time;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    AlarmManager alarmManager;
    PendingIntent pendingIntent;
    public static Ringtone ringtone;
    TimePicker timePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        ToggleButton toggleButton = (ToggleButton) findViewById(R.id.togButt);
        timePicker = (TimePicker) findViewById(R.id.tipick);
    }

        public void onToggleClicked(View view)
    {
        if(((ToggleButton)view).isChecked())
        {
            Toast.makeText(MainActivity.this,"Alarm ON ",Toast.LENGTH_LONG).show();
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY,timePicker.getCurrentHour());
            calendar.set(Calendar.MINUTE,timePicker.getCurrentMinute());
            long time = (calendar.getTimeInMillis()-calendar.getTimeInMillis()%60000);
            Intent intent = new Intent(this,AlarmReceiver.class);
            pendingIntent = PendingIntent.getBroadcast(this,0,intent,0);

            if(System.currentTimeMillis() > time)
            {
                if(calendar.AM_PM==0)
                {

                    time = time + (60*60*1000*12);
                }
                else
                {
                    time = time + (60*60*1000*24);
                }
            }

            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,time,10000,pendingIntent);
        }

        else
        {
            ringtone.stop();
            alarmManager.cancel(pendingIntent);
            Toast.makeText(this,"Alarm off",Toast.LENGTH_LONG).show();
        }

    }


}
