package com.example.priya.testing;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.media.app.NotificationCompat;
import android.widget.Toast;

import static android.support.v4.media.app.NotificationCompat.*;

/**
 * Created by priya on 15/4/18.
 */

public class AlarmReceiver extends BroadcastReceiver{


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "Alarm  Wake up!", Toast.LENGTH_LONG).show();
        Uri alarmuri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

        if (alarmuri == null) {
            alarmuri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        }

        MainActivity.ringtone = RingtoneManager.getRingtone(context, alarmuri);
        MainActivity.ringtone.play();


        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setContentTitle("Alarm !!");
        builder.setContentText("Wake Up! ");

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel("1", "Alarm ", importance);
            notificationChannel.setDescription("Wake up !!!");
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
            notificationManager.notify(0, builder.build());

        }
        else {
            Notification notification = builder.build();
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0,notification);
        }

    }
}
