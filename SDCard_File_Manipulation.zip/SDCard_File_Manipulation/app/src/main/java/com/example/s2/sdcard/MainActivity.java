package com.example.s2.sdcard;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText filename = (EditText) findViewById(R.id.filename);
        final EditText content = (EditText) findViewById(R.id.contents);
        Button write = (Button) findViewById(R.id.write);
        Button read = (Button) findViewById(R.id.read);
        final EditText status = (EditText) findViewById(R.id.status);

        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String fname = filename.getText().toString();
                File file = new File(getExternalCacheDir(),fname);
                if(file.exists())
                    status.setText("Old File");
                else {
                    status.setText("New File");

                    if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
                        status.setText("SD is not there ");
                    }
                    else {
                        File path =
                                new File(Environment.getExternalStorageDirectory() + File.separator + "4075");
                        // Create the folder.
                        File folder = new File(path.getAbsolutePath());
                        folder.mkdirs();

                        try {
                            // Create FIle Objec which I need to write
                            File fileToWrite = new File(folder, filename.getText().toString() + ".txt");
                                //Create a stream to file path
                                FileOutputStream outPutStream = new FileOutputStream(fileToWrite);
                                //Create Writer to write STream to file Path
                                OutputStreamWriter outPutStreamWriter = new OutputStreamWriter(outPutStream);
                                // Stream Byte Data to the file
                                outPutStreamWriter.append(content.getText().toString());
                                //Close Writer
                                outPutStreamWriter.close();
                                //Clear Stream
                                outPutStream.flush();
                                //Terminate STream
                                outPutStream.close();
                                status.setText("Contents are copied");

                        } catch (IOException e) {
                            status.setText("Failure in creating");
                            Log.e("Exception", "Error: File write failed: " + e.toString());
                            e.fillInStackTrace();
                        }

                    }
                }


            }
        });

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                status.setText("Hello readers..");
                File sdcard = new File(Environment.getExternalStorageDirectory() + File.separator + "4075");

//Get the text file
                File file = new File(sdcard,filename.getText().toString()+".txt");

//Read text from file
                StringBuilder text = new StringBuilder();

                try {
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    String line;

                    while ((line = br.readLine()) != null) {
                        text.append(line);
                        text.append('\n');
                    }

                    br.close();
                }
                catch (IOException e) {
                    //You'll need to add proper error handling here
                }

//Find the view by its id

//Set the text
                Intent i = new Intent(getApplicationContext(),NextActivity.class);
                final Bundle b = new Bundle();
                b.putString("fname", filename.getText().toString());
                b.putString("content", text.toString());
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_next);

             //   status.setText(text.toString());
            }
        });



    }
}
