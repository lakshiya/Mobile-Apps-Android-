package com.example.priya.sampi;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED)
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.RECEIVE_SMS))
            {}
            else
            {
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECEIVE_SMS},0);

            }
        BroadcastReceiver br = new SMSReceiver();
        IntentFilter intentFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        this.registerReceiver(br,intentFilter);


        }

        public void sendSMS(View view)
        {
            EditText editText = (EditText) findViewById(R.id.phno);
            EditText editText1 = (EditText) findViewById(R.id.mess);
            String phno = editText.getText().toString();
            String message = editText1.getText().toString();

            if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
                if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.SEND_SMS))
                {}
                else
                {
                    ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},0);

                }

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phno,null,message,null,null);
            Toast.makeText(this,"SEND SMS ",Toast.LENGTH_LONG).show();
        }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        EditText editText = (EditText) findViewById(R.id.phno);
        EditText editText1 = (EditText) findViewById(R.id.mess);
        String phno = editText.getText().toString();
        String message = editText1.getText().toString();

        switch (requestCode){
            case 0:
            {
                if(grantResults.length>0)
                {
                    if(grantResults[0]==PackageManager.PERMISSION_GRANTED)
                    {
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phno,null,message,null,null);
                        Toast.makeText(this,"SEND SMS ",Toast.LENGTH_LONG).show();
                    }
                }
                else
                {
                    Toast.makeText(this,"Failed to send SMS ",Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}
