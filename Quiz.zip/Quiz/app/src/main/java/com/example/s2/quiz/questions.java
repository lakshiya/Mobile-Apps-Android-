package com.example.s2.quiz;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class questions extends AppCompatActivity {

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        SQLiteDatabase.CursorFactory factory;

        final DatabaseHelper db = new DatabaseHelper(this);
       // Toast.makeText(getApplicationContext(),"Database Created",Toast.LENGTH_LONG).show();

//        float val = db.insertVal(1,"what is moon?","planet","star","metroid","galaxy");
//        float val1 = db.insertVal(2,"what is earth?","planet","star","metroid","galaxy");
//        float val2 = db.insertVal(3,"what is milkyway?","planet","star","metroid","galaxy");
//        float val3 = db.insertVal(4,"what is jupiter?","planet","star","metroid","galaxy");
//        float val4 = db.insertVal(5,"what is sun?","planet","star","metroid","galaxy");

       //  float val =  db.insertVal(new student(name,"male","eee",numb));

//        Toast toast = Toast.makeText(getApplicationContext(), "Inserted "+"  yes",
//                Toast.LENGTH_LONG);
//        toast.setGravity(Gravity.TOP|Gravity.LEFT, 300, 1400);
//        toast.show();

        final String correctOption[] =new String[] {"star","planet","galaxy","planet","star"};
        final String selectedOption[] = new String[20];
        int countQ = 5;
        Intent in = getIntent();
        final Bundle b = in.getExtras();
        int qno = b.getInt("qno");
        int points = b.getInt("points");

         int tempQno = qno;
         int tempPoints = points;


//        Toast toast1 = Toast.makeText(getApplicationContext(), "qno "+ qno +"  yes",
//                Toast.LENGTH_LONG);
//        toast1.setGravity(Gravity.TOP|Gravity.LEFT, 300, 1400);
//        toast1.show();


        Cursor cursor = db.retrieveVal(qno);

        if(cursor!=null)
        {
            //Toast.makeText(getApplicationContext(),"Got it",Toast.LENGTH_LONG).show();
            if(cursor.moveToNext())
            {
               // Toast.makeText(getApplicationContext(),"Got next ",Toast.LENGTH_LONG).show();

                do{
//                    String sname = cursor.getString(cursor.getColumnIndex("id"));
//                    TextView qsno = (TextView) findViewById(R.id.qsno);
//                    qsno.setText(sname);

                    String quest = cursor.getString(cursor.getColumnIndex("q"));
                    TextView q_desc = (TextView) findViewById(R.id.quest);
                    q_desc.setText(quest);


                    String op1 = cursor.getString(cursor.getColumnIndex("option1"));
                    RadioButton opti1 = (RadioButton) findViewById(R.id.option1);
                    opti1.setText(op1);

                    String op2 = cursor.getString(cursor.getColumnIndex("option2"));
                    RadioButton opti2 = (RadioButton) findViewById(R.id.option2);
                    opti2.setText(op2);

                    String op3 = cursor.getString(cursor.getColumnIndex("option3"));
                    RadioButton opti3 = (RadioButton) findViewById(R.id.option3);
                    opti3.setText(op3);

                    String op4 = cursor.getString(cursor.getColumnIndex("option4"));
                    RadioButton opti4 = (RadioButton) findViewById(R.id.option4);
                    opti4.setText(op4);


                }while (cursor.moveToNext());
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Errorrrr ",Toast.LENGTH_LONG).show();

            }
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Errorrrr mtn ",Toast.LENGTH_LONG).show();

        }
        //  scrollView.addView(layout);

        Button next = (Button) findViewById(R.id.next);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent in = getIntent();
                Bundle b = in.getExtras();
                int qno = b.getInt("qno");
                int points = b.getInt("points");

                if(qno<=5) {

                    RadioGroup answer = (RadioGroup) findViewById(R.id.chosen);
                    int selectedeId = answer.getCheckedRadioButtonId();

                    RadioButton chosen = (RadioButton) findViewById(selectedeId);
                    String values = (String) chosen.getText();

                    selectedOption[qno - 1] = values;

                    if (values.equals(correctOption[qno - 1])) {
                        points++;
                   }
                    qno++;

                    Intent i = new Intent(getApplicationContext(), questions.class);
                    Bundle bu = new Bundle();
                    bu.putInt("qno", qno);
                    bu.putInt("points", points);

                    i.putExtras(bu);
                    startActivity(i);
                    setContentView(R.layout.activity_questions);

                }

                if(qno>5)
                {

                    Intent i = new Intent(getApplicationContext(),ResultActivity.class);
                    Bundle ba = new Bundle();
                    ba.putInt("finalPoints",points);
                    i.putExtras(ba);
                    startActivity(i);
                    setContentView(R.layout.activity_result);
                }
            }
        });

        Button previous = (Button) findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent in = getIntent();
                Bundle b = in.getExtras();
                int qno = b.getInt("qno");
                int points = b.getInt("points");

                if(qno<=5 && qno>0) {

                    points--;
                    RadioGroup answer = (RadioGroup) findViewById(R.id.chosen);
                    int selectedeId = answer.getCheckedRadioButtonId();

                    RadioButton chosen = (RadioButton) findViewById(selectedeId);
                    String values = (String) chosen.getText();

                    selectedOption[qno - 1] = values;

                    if (values.equals(correctOption[qno - 1])) {
                        points++;
                    }
                    qno--;

                    Intent i = new Intent(getApplicationContext(), questions.class);
                    Bundle bu = new Bundle();
                    bu.putInt("qno", qno);
                    bu.putInt("points", points);

                    i.putExtras(bu);
                    startActivity(i);
                    setContentView(R.layout.activity_questions);

                }

                if(qno==0)
                {

                    Intent i = new Intent(getApplicationContext(),MainActivity.class);
                    Bundle ba = new Bundle();
                    ba.putInt("qno", 1);
                    ba.putInt("points", points);
                    //ba.putInt("finalPoints",points);
                    i.putExtras(ba);
                    startActivity(i);
                    setContentView(R.layout.activity_result);
                }
            }
        });

    }


    }

