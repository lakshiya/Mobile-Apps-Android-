package com.example.s2.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent in = getIntent();
        Bundle b = in.getExtras();
        int finalPoints = b.getInt("finalPoints");

        Toast toast1 = Toast.makeText(getApplicationContext(), "Final points " + finalPoints,
                Toast.LENGTH_SHORT);
        toast1.setGravity(Gravity.TOP | Gravity.LEFT, 300, 1400);
        toast1.show();

        TextView result = (TextView) findViewById(R.id.result);

        result.setText(Integer.toString(finalPoints));

        Button toMain = (Button) findViewById(R.id.toMain);
        Button toTest = (Button) findViewById(R.id.toTest);

        toMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                Bundle b = new Bundle();
                b.putInt("qno",1);
                b.putInt("points",0);
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_main);
            }
        });

        toTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(),questions.class);
                Bundle b = new Bundle();
                b.putInt("qno",1);
                b.putInt("points",0);
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_questions);
            }
        });
    }
}
