package com.example.s2.quiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by s2 on 3/26/2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private  static final String db_name = "QUESTIONS";
    private  static final String q_desc = "q";
    private  static final String q_opt1 = "option1";
    private  static final String q_opt2 = "option2";
    private  static final String q_opt3 = "option3";
    private  static final String q_opt4 = "option4";
    private static final  String key_id = "id";

    public DatabaseHelper(Context context) {
        super(context,db_name,null, (int) 1.0);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String drop = "DROP TABLE IF EXISTS STUDENTS;";
        sqLiteDatabase.execSQL(drop);

        String create_table = "CREATE TABLE QUESTIONS ( " + key_id +" INTEGER ,"+ q_desc +" char(200),"+ q_opt1+" char(15),"+q_opt2+" char(20),"+q_opt3+"  char(15),"+q_opt4+"  char(15));";
        sqLiteDatabase.execSQL(create_table);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        onCreate(sqLiteDatabase);

    }

    public float insertVal(int qid,String question,String opt1,String opt2,String opt3,String opt4)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(key_id,qid);
        contentValues.put(q_desc,question);
        contentValues.put(q_opt1,opt1);
        contentValues.put(q_opt2,opt2);
        contentValues.put(q_opt3,opt3);
        contentValues.put(q_opt4,opt4);


        long value = db.insert(db_name,null,contentValues);

        Log.d("ok","Is Inserted "+value);
        db.close();

        return value;
    }

    public float updateVal(String name,String gender,String department,int phno,int oldno)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        if(name!=null)
        {
            Cursor cursor = db.rawQuery("UPDATE STUDENTS SET NAME ='"+name+"' WHERE CNUM = '"+oldno+"'",null);
            cursor.moveToFirst();
            cursor.close();
        }

        if(gender!=null)
        {
            Cursor cursor2 = db.rawQuery("UPDATE STUDENTS SET GENDER ='"+gender+"' WHERE CNUM = '"+oldno+"'",null);
            cursor2.moveToFirst();
            cursor2.close();
        }

        if(department!=null)
        {
            Cursor cursor3 = db.rawQuery("UPDATE STUDENTS SET DEPARTMENT ='"+department+"' WHERE CNUM = '"+oldno+"'",null);
            cursor3.moveToFirst();
            cursor3.close();
        }

        if(phno!=0)
        {
            Cursor cursor4 = db.rawQuery("UPDATE STUDENTS SET CNUM ='"+phno+"' WHERE CNUM = '"+oldno+"'",null);
            cursor4.moveToFirst();
            cursor4.close();
        }
        return 1;
    }

    public Cursor retrieveVal(Integer qnos) {
        SQLiteDatabase db = this.getReadableDatabase();

        if (qnos == -1) {
            Cursor cursor = db.rawQuery("SELECT * FROM STUDENTS ", null);
            return cursor;
        }

        else
        {
            String num = qnos.toString();
            Cursor cursor = db.rawQuery("SELECT * FROM QUESTIONS WHERE id ='"+qnos+"' ",null);


            if(cursor!=null)
            Log.d("ok","It exists ");
            return cursor;

        }
    }

    public void deleteVal(Integer phno) {
        SQLiteDatabase db = this.getWritableDatabase();

        String num = phno.toString();
        Cursor cursor = db.rawQuery("DELETE FROM STUDENTS WHERE CNUM= '"+num+"'",null);
        Log.d("check","DELETE FROM STUDENTS WHERE CNUM= "+num);
        cursor.moveToNext();
        cursor.close();


    }

}

