package com.example.s2.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class InsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins);

        Button insToTest = (Button) findViewById(R.id.insToTest);

        insToTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(),questions.class);
                Bundle b = new Bundle();
                b.putInt("qno",1);
                b.putInt("points",0);
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_questions);
            }
        });
    }
}
