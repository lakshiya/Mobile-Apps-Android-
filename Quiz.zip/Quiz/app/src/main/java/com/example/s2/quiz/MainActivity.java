package com.example.s2.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button goQuiz = (Button)findViewById(R.id.quiz);
        Button instruction = (Button) findViewById(R.id.instruction);

        goQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(),questions.class);
                Bundle b = new Bundle();
                b.putInt("qno",1);
                b.putInt("points",0);
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_questions);
            }
        });

        instruction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(),InsActivity.class);
                Bundle b = new Bundle();
                i.putExtras(b);
                startActivity(i);
                setContentView(R.layout.activity_ins);

            }
        });


    }
}
